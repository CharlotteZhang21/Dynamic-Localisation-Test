var CONFIG = {
    closeButtonTimer: 5,
    startTimer: 2,
    inactiveTimer: 10,
    gameplayTimer: 30,

    initialAngle: -Math.PI * 0.45,
    angleRange: Math.PI * 0.2,
    distance: 155,
    distanceRange: 30,
    zoomRange: [10, 17]
};